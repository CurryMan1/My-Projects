from enum import Enum


class States(Enum):
    START = 0
    GAME = 1
    SIGN_IN = 2
